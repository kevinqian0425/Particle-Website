import sys
import collections

#Save the current stream
save_out = sys.stdout

#Create the log file
f = "test_file.log"
#Append and write to log file
fsock = open(f,'w')

#set stream to file
sys.stdout = fsock

#print function calls will send the stream to file f
data = {
	"Email": "x-JosephWeis@tesla.com",
	"First Name":'Joseph',
	"Last Name": 'Weis',
	"Default Key 1": 1,
	"Company": 'Maumee Assembly & Stamping',
	"Default Key 2": 3,
	"Company Email": 'jweis@mastamping.com',
	"Date Joined": '2017-06-06 10:38:51',
	"Default Key 3": 1,
	"Default Key 4": None,
	"Default Key 5": 7749,
	"Date Left": '2017-09-19 21:23:55',
	"Default Key 6": 0,
	"Default Key 7": 0,
	"Default Key 8": 3325,
	"Default Key 9": 1,
	"Implementation Date": '2016-08-15 19:52:09',
	"Default Key 10": None,
	"Default Key 11": None,
	"Default Key 12": None,
	"Status": 'SP user group updated successfully',
	"Default Key 13": 143,
	"Ticket Number": '134768',
	"Default Key 14": 86389
}

for i in sorted(data.items(),key=lambda x: x[0]):
	print i


# Reset back the stream to what it was
# any print function calls will send the stream to the previous stream
