function f(a) {
  a.parentNode.getElementsByClassName('dropdown')[0].classList.toggle('down');
  a.parentNode.getElementsByClassName('arrow')[0].classList.toggle('gone');
  if (a.parentNode.getElementsByClassName('dropdown')[0].classList.contains('down')) {
    setTimeout(function() {
      a.parentNode.getElementsByClassName('dropdown')[0].style.overflow = 'visible'
    }, 500)
  }
  else {
    a.parentNode.getElementsByClassName('dropdown')[0].style.overflow = 'hidden'
  }
}
