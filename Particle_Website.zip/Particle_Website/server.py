from time import sleep
from flask import Flask, render_template, Response
from flask_bootstrap import Bootstrap

app = Flask(__name__)
Bootstrap(app)

@app.route('/')
def index():
	# render the template that will use Javascript to read the stream
    return render_template('button.html')

#read from file forever and stream the output
@app.route('/stream')
def stream():
    def generate():
        with open('test_file.log') as f:
            while True:
                yield f.read()
				#sleep between reads to reduce cpu load from the endless loop and allow other threads more active time
                sleep(1)

    return Response(generate(), mimetype='text/plain')
    return render_template('button.html')

if __name__ == "__main__":
    app.run(debug=True)
